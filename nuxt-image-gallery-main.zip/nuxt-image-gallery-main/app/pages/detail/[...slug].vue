<template>
  <div>
    <ImageDetail />
  </div>
</template>
