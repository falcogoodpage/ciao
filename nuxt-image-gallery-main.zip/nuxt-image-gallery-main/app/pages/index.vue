<template>
  <main>
    <ImageGallery />
  </main>
</template>
